#pragma once
//  To parse this JSON data, first install
//
//      json.hpp  https://github.com/nlohmann/json
//
//  Then include this file, and then do
//
//     vyper::vyper data = nlohmann::json::parse(jsonString);
//
//  You can get std::wstring data back out using
//
//     std::wcout << vyper::wdump((nlohmann::json) vyper);

#pragma once

#include "nlohmann/json.hpp"

#include <optional>
#include <stdexcept>
#include <regex>
#include <codecvt>
#include <locale>

#ifndef NLOHMANN_OPT_HELPER
#define NLOHMANN_OPT_HELPER
namespace nlohmann {
    template <typename T>
    struct adl_serializer<std::shared_ptr<T>> {
        static void to_json(json& j, const std::shared_ptr<T>& opt) {
            if (!opt) j = nullptr; else j = *opt;
        }

        static std::shared_ptr<T> from_json(const json& j) {
            if (j.is_null()) return std::unique_ptr<T>(); else return std::unique_ptr<T>(new T(j.get<T>()));
        }
    };
}
#endif

namespace vyper {
    using nlohmann::json;

    template<typename T>
    struct tag {};

    template<typename fromType, typename toType>
    class Utf16_Utf8 {
    private:
        template<typename TF, typename TT>
        static toType convert(tag<std::shared_ptr<TF> >, tag<std::shared_ptr<TT> >, fromType ptr) {
            if (ptr == nullptr) return std::unique_ptr<TT>(); else return std::unique_ptr<TT>(new TT(Utf16_Utf8<TF, TT>::convert(*ptr)));
        }

        template<typename TF, typename TT>
        static toType convert(tag<std::vector<TF> >, tag<std::vector<TT> >, fromType v) {
            auto it = v.begin();
            auto newVector = std::vector<TT>();
            while (it != v.end()) {
                newVector.push_back(Utf16_Utf8<TF, TT>::convert(*it));
                it++;
            }
            return newVector;
        }

        template<typename KF, typename VF, typename KT, typename VT>
        static toType convert(tag<std::map<KF, VF> >, tag<std::map<KT, VT> >, fromType m) {
            auto it = m.begin();
            auto newMap = std::map<KT, VT>();
            while (it != m.end()) {
                newMap.insert(std::pair<KT, VT>(Utf16_Utf8<KF, KT>::convert(it->first), Utf16_Utf8<VF, VT>::convert(it->second)));
                it++;
            }
            return newMap;
        }

        template<typename TF, typename TT>
        static fromType convert(tag<TF>, tag<TT>, fromType from) {
            return from;
        }

        static std::wstring convert(tag<std::string>, tag<std::wstring>, std::string str) {
            return std::wstring_convert<std::codecvt_utf8_utf16<wchar_t, 0x10ffff, std::little_endian>, wchar_t>{}.from_bytes(str.data());
        }

        static std::string convert(tag<std::wstring>, tag<std::string>, std::wstring str) {
            return std::wstring_convert<std::codecvt_utf8_utf16<wchar_t, 0x10ffff, std::little_endian>, wchar_t>{}.to_bytes(str.data());
        }

    public:
        static toType convert(fromType in) {
            return convert(tag<fromType>(), tag<toType>(), in);
        }
    };

    template<typename T>
    std::wstring wdump(const T& j) {
        std::ostringstream s;
        s << j;
        return vyper::Utf16_Utf8<std::string, std::wstring>::convert(s.str());
    }

    inline json get_untyped(const json& j, const char* property) {
        if (j.find(property) != j.end()) {
            return j.at(property).get<json>();
        }
        return json();
    }

    inline json get_untyped(const json& j, std::string property) {
        return get_untyped(j, property.data());
    }

    template <typename T>
    inline std::shared_ptr<T> get_optional(const json& j, const char* property) {
        if (j.find(property) != j.end()) {
            return j.at(property).get<std::shared_ptr<T>>();
        }
        return std::shared_ptr<T>();
    }

    template <typename T>
    inline std::shared_ptr<T> get_optional(const json& j, std::string property) {
        return get_optional<T>(j, property.data());
    }

    enum class file_path : int { APP_DATA_VYPER_INDUSTRIES_MFDMF_TEST_PATTERNS };

    class sub_config_def {
    public:
        sub_config_def() = default;
        virtual ~sub_config_def() = default;

    private:
        std::shared_ptr<std::wstring> name;
        std::shared_ptr<std::wstring> file_name;
        std::shared_ptr<int64_t> width;
        std::shared_ptr<int64_t> height;
        std::shared_ptr<bool> center;
        std::shared_ptr<int64_t> x_offset_start;
        std::shared_ptr<int64_t> x_offset_finish;
        std::shared_ptr<int64_t> y_offset_start;
        std::shared_ptr<int64_t> y_offset_finish;
        std::shared_ptr<std::vector<vyper::sub_config_def>> sub_config_def_field;
        std::shared_ptr<double> opacity;
        std::shared_ptr<int64_t> left;
        std::shared_ptr<int64_t> top;
        std::shared_ptr<bool> enabled;
        std::shared_ptr<bool> use_as_switch;
        std::shared_ptr<bool> make_opaque;
        std::shared_ptr<vyper::file_path> file_path;

    public:
        std::shared_ptr<std::wstring> get_name() const { return name; }
        void set_name(std::shared_ptr<std::wstring> value) { this->name = value; }

        std::shared_ptr<std::wstring> get_file_name() const { return file_name; }
        void set_file_name(std::shared_ptr<std::wstring> value) { this->file_name = value; }

        std::shared_ptr<int64_t> get_width() const { return width; }
        void set_width(std::shared_ptr<int64_t> value) { this->width = value; }

        std::shared_ptr<int64_t> get_height() const { return height; }
        void set_height(std::shared_ptr<int64_t> value) { this->height = value; }

        std::shared_ptr<bool> get_center() const { return center; }
        void set_center(std::shared_ptr<bool> value) { this->center = value; }

        std::shared_ptr<int64_t> get_x_offset_start() const { return x_offset_start; }
        void set_x_offset_start(std::shared_ptr<int64_t> value) { this->x_offset_start = value; }

        std::shared_ptr<int64_t> get_x_offset_finish() const { return x_offset_finish; }
        void set_x_offset_finish(std::shared_ptr<int64_t> value) { this->x_offset_finish = value; }

        std::shared_ptr<int64_t> get_y_offset_start() const { return y_offset_start; }
        void set_y_offset_start(std::shared_ptr<int64_t> value) { this->y_offset_start = value; }

        std::shared_ptr<int64_t> get_y_offset_finish() const { return y_offset_finish; }
        void set_y_offset_finish(std::shared_ptr<int64_t> value) { this->y_offset_finish = value; }

        std::shared_ptr<std::vector<vyper::sub_config_def>> get_sub_config_def() const { return sub_config_def_field; }
        void set_sub_config_def(std::shared_ptr<std::vector<vyper::sub_config_def>> value) { this->sub_config_def_field = value; }

        std::shared_ptr<double> get_opacity() const { return opacity; }
        void set_opacity(std::shared_ptr<double> value) { this->opacity = value; }

        std::shared_ptr<int64_t> get_left() const { return left; }
        void set_left(std::shared_ptr<int64_t> value) { this->left = value; }

        std::shared_ptr<int64_t> get_top() const { return top; }
        void set_top(std::shared_ptr<int64_t> value) { this->top = value; }

        std::shared_ptr<bool> get_enabled() const { return enabled; }
        void set_enabled(std::shared_ptr<bool> value) { this->enabled = value; }

        std::shared_ptr<bool> get_use_as_switch() const { return use_as_switch; }
        void set_use_as_switch(std::shared_ptr<bool> value) { this->use_as_switch = value; }

        std::shared_ptr<bool> get_make_opaque() const { return make_opaque; }
        void set_make_opaque(std::shared_ptr<bool> value) { this->make_opaque = value; }

        std::shared_ptr<vyper::file_path> get_file_path() const { return file_path; }
        void set_file_path(std::shared_ptr<vyper::file_path> value) { this->file_path = value; }
    };

    class configuration {
    public:
        configuration() = default;
        virtual ~configuration() = default;

    private:
        std::shared_ptr<std::wstring> name;
        std::shared_ptr<bool> use_as_switch;
        std::shared_ptr<bool> make_opaque;
        std::shared_ptr<std::vector<vyper::sub_config_def>> sub_config_def;
        std::shared_ptr<std::wstring> file_name;
        std::shared_ptr<bool> enabled;

    public:
        std::shared_ptr<std::wstring> get_name() const { return name; }
        void set_name(std::shared_ptr<std::wstring> value) { this->name = value; }

        std::shared_ptr<bool> get_use_as_switch() const { return use_as_switch; }
        void set_use_as_switch(std::shared_ptr<bool> value) { this->use_as_switch = value; }

        std::shared_ptr<bool> get_make_opaque() const { return make_opaque; }
        void set_make_opaque(std::shared_ptr<bool> value) { this->make_opaque = value; }

        std::shared_ptr<std::vector<vyper::sub_config_def>> get_sub_config_def() const { return sub_config_def; }
        void set_sub_config_def(std::shared_ptr<std::vector<vyper::sub_config_def>> value) { this->sub_config_def = value; }

        std::shared_ptr<std::wstring> get_file_name() const { return file_name; }
        void set_file_name(std::shared_ptr<std::wstring> value) { this->file_name = value; }

        std::shared_ptr<bool> get_enabled() const { return enabled; }
        void set_enabled(std::shared_ptr<bool> value) { this->enabled = value; }
    };

    class module_element {
    public:
        module_element() = default;
        virtual ~module_element() = default;

    private:
        std::shared_ptr<std::wstring> name;
        std::shared_ptr<std::wstring> display_name;
        std::shared_ptr<std::wstring> file_path;
        std::shared_ptr<std::wstring> file_name;
        std::shared_ptr<std::vector<vyper::configuration>> configurations;

    public:
        std::shared_ptr<std::wstring> get_name() const { return name; }
        void set_name(std::shared_ptr<std::wstring> value) { this->name = value; }

        std::shared_ptr<std::wstring> get_display_name() const { return display_name; }
        void set_display_name(std::shared_ptr<std::wstring> value) { this->display_name = value; }

        std::shared_ptr<std::wstring> get_file_path() const { return file_path; }
        void set_file_path(std::shared_ptr<std::wstring> value) { this->file_path = value; }

        std::shared_ptr<std::wstring> get_file_name() const { return file_name; }
        void set_file_name(std::shared_ptr<std::wstring> value) { this->file_name = value; }

        std::shared_ptr<std::vector<vyper::configuration>> get_configurations() const { return configurations; }
        void set_configurations(std::shared_ptr<std::vector<vyper::configuration>> value) { this->configurations = value; }
    };

    class vyper {
    public:
        vyper() = default;
        virtual ~vyper() = default;

    private:
        std::shared_ptr<std::vector<vyper::module_element>> modules;

    public:
        std::shared_ptr<std::vector<vyper::module_element>> get_modules() const { return modules; }
        void set_modules(std::shared_ptr<std::vector<vyper::module_element>> value) { this->modules = value; }
    };
}

namespace nlohmann {
    namespace detail {
        void from_json(const json& j, vyper::sub_config_def& x);
        void to_json(json& j, const vyper::sub_config_def& x);

        void from_json(const json& j, vyper::configuration& x);
        void to_json(json& j, const vyper::configuration& x);

        void from_json(const json& j, vyper::module_element& x);
        void to_json(json& j, const vyper::module_element& x);

        void from_json(const json& j, vyper::vyper& x);
        void to_json(json& j, const vyper::vyper& x);

        void from_json(const json& j, vyper::file_path& x);
        void to_json(json& j, const vyper::file_path& x);

        inline void from_json(const json& j, vyper::sub_config_def& x) {
            x.set_name(vyper::Utf16_Utf8<std::shared_ptr<std::string>, std::shared_ptr<std::wstring>>::convert(vyper::get_optional<std::string>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"name"))));
            x.set_file_name(vyper::Utf16_Utf8<std::shared_ptr<std::string>, std::shared_ptr<std::wstring>>::convert(vyper::get_optional<std::string>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"fileName"))));
            x.set_width(vyper::get_optional<int64_t>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"width")));
            x.set_height(vyper::get_optional<int64_t>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"height")));
            x.set_center(vyper::get_optional<bool>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"center")));
            x.set_x_offset_start(vyper::get_optional<int64_t>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"xOffsetStart")));
            x.set_x_offset_finish(vyper::get_optional<int64_t>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"xOffsetFinish")));
            x.set_y_offset_start(vyper::get_optional<int64_t>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"yOffsetStart")));
            x.set_y_offset_finish(vyper::get_optional<int64_t>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"yOffsetFinish")));
            x.set_sub_config_def(vyper::get_optional<std::vector<vyper::sub_config_def>>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"subConfigDef")));
            x.set_opacity(vyper::get_optional<double>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"opacity")));
            x.set_left(vyper::get_optional<int64_t>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"left")));
            x.set_top(vyper::get_optional<int64_t>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"top")));
            x.set_enabled(vyper::get_optional<bool>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"enabled")));
            x.set_use_as_switch(vyper::get_optional<bool>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"useAsSwitch")));
            x.set_make_opaque(vyper::get_optional<bool>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"makeOpaque")));
            x.set_file_path(vyper::get_optional<vyper::file_path>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"filePath")));
        }

        inline void to_json(json& j, const vyper::sub_config_def& x) {
            j = json::object();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"name")] = vyper::Utf16_Utf8<std::shared_ptr<std::wstring>, std::shared_ptr<std::string>>::convert(x.get_name());
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"fileName")] = vyper::Utf16_Utf8<std::shared_ptr<std::wstring>, std::shared_ptr<std::string>>::convert(x.get_file_name());
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"width")] = x.get_width();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"height")] = x.get_height();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"center")] = x.get_center();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"xOffsetStart")] = x.get_x_offset_start();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"xOffsetFinish")] = x.get_x_offset_finish();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"yOffsetStart")] = x.get_y_offset_start();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"yOffsetFinish")] = x.get_y_offset_finish();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"subConfigDef")] = x.get_sub_config_def();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"opacity")] = x.get_opacity();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"left")] = x.get_left();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"top")] = x.get_top();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"enabled")] = x.get_enabled();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"useAsSwitch")] = x.get_use_as_switch();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"makeOpaque")] = x.get_make_opaque();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"filePath")] = x.get_file_path();
        }

        inline void from_json(const json& j, vyper::configuration& x) {
            x.set_name(vyper::Utf16_Utf8<std::shared_ptr<std::string>, std::shared_ptr<std::wstring>>::convert(vyper::get_optional<std::string>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"name"))));
            x.set_use_as_switch(vyper::get_optional<bool>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"useAsSwitch")));
            x.set_make_opaque(vyper::get_optional<bool>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"makeOpaque")));
            x.set_sub_config_def(vyper::get_optional<std::vector<vyper::sub_config_def>>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"subConfigDef")));
            x.set_file_name(vyper::Utf16_Utf8<std::shared_ptr<std::string>, std::shared_ptr<std::wstring>>::convert(vyper::get_optional<std::string>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"fileName"))));
            x.set_enabled(vyper::get_optional<bool>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"enabled")));
        }

        inline void to_json(json& j, const vyper::configuration& x) {
            j = json::object();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"name")] = vyper::Utf16_Utf8<std::shared_ptr<std::wstring>, std::shared_ptr<std::string>>::convert(x.get_name());
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"useAsSwitch")] = x.get_use_as_switch();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"makeOpaque")] = x.get_make_opaque();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"subConfigDef")] = x.get_sub_config_def();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"fileName")] = vyper::Utf16_Utf8<std::shared_ptr<std::wstring>, std::shared_ptr<std::string>>::convert(x.get_file_name());
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"enabled")] = x.get_enabled();
        }

        inline void from_json(const json& j, vyper::module_element& x) {
            x.set_name(vyper::Utf16_Utf8<std::shared_ptr<std::string>, std::shared_ptr<std::wstring>>::convert(vyper::get_optional<std::string>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"name"))));
            x.set_display_name(vyper::Utf16_Utf8<std::shared_ptr<std::string>, std::shared_ptr<std::wstring>>::convert(vyper::get_optional<std::string>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"displayName"))));
            x.set_file_path(vyper::Utf16_Utf8<std::shared_ptr<std::string>, std::shared_ptr<std::wstring>>::convert(vyper::get_optional<std::string>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"filePath"))));
            x.set_file_name(vyper::Utf16_Utf8<std::shared_ptr<std::string>, std::shared_ptr<std::wstring>>::convert(vyper::get_optional<std::string>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"fileName"))));
            x.set_configurations(vyper::get_optional<std::vector<vyper::configuration>>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"configurations")));
        }

        inline void to_json(json& j, const vyper::module_element& x) {
            j = json::object();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"name")] = vyper::Utf16_Utf8<std::shared_ptr<std::wstring>, std::shared_ptr<std::string>>::convert(x.get_name());
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"displayName")] = vyper::Utf16_Utf8<std::shared_ptr<std::wstring>, std::shared_ptr<std::string>>::convert(x.get_display_name());
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"filePath")] = vyper::Utf16_Utf8<std::shared_ptr<std::wstring>, std::shared_ptr<std::string>>::convert(x.get_file_path());
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"fileName")] = vyper::Utf16_Utf8<std::shared_ptr<std::wstring>, std::shared_ptr<std::string>>::convert(x.get_file_name());
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"configurations")] = x.get_configurations();
        }

        inline void from_json(const json& j, vyper::vyper& x) {
            x.set_modules(vyper::get_optional<std::vector<vyper::module_element>>(j, vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"modules")));
        }

        inline void to_json(json& j, const vyper::vyper& x) {
            j = json::object();
            j[vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"modules")] = x.get_modules();
        }

        inline void from_json(const json& j, vyper::file_path& x) {
            if (j == vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"%AppData%\\Vyper Industries\\MFDMF\\TestPatterns")) x = vyper::file_path::APP_DATA_VYPER_INDUSTRIES_MFDMF_TEST_PATTERNS;
            else throw "Input JSON does not conform to schema";
        }

        inline void to_json(json& j, const vyper::file_path& x) {
            switch (x) {
            case vyper::file_path::APP_DATA_VYPER_INDUSTRIES_MFDMF_TEST_PATTERNS: j = vyper::Utf16_Utf8<std::wstring, std::string>::convert(L"%AppData%\\Vyper Industries\\MFDMF\\TestPatterns"); break;
            default: throw "This should not happen";
            }
        }
    }
}
